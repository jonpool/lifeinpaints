Thanks for downloading this theme!

Theme Name: MyBiz
Theme URL: https://bootstrapmade.com/mybiz-free-business-bootstrap-theme/
Author: BootstrapMade.com
Author URL: https://bootstrapmade.com